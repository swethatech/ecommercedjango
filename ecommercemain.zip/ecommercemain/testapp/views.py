from django.shortcuts import render, redirect
from testapp.models import Ecommerce
from django.views.generic import DetailView
from testapp.forms import ConfirmationForm,CreateUserForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout


def registerPage(request):
    if request.user.is_authenticated:
        return redirect('/home')
    else:
        form = UserCreationForm()
        if request.method == 'POST':
            form = UserCreationForm(request.POST)
            if form.is_valid():
                form.save()
            return redirect('/accounts/login')
        my_dict = {'form': form}
        return render(request, "accounts/register.html", my_dict)


def login_page(request):
    if request.user.is_authenticated:
        return redirect('/home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('/home')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'accounts/login.html', context)

def logoutUser(request):
	logout(request)
	return redirect('/register')

@login_required(login_url='/register')
def fetch_products(request):
    ecommerce = Ecommerce.objects.all()
    item_name = request.GET.get('item_name')
    if item_name != '' and item_name is not None:
        ecommerce = ecommerce.filter(name__contains=item_name)
    my_dict = {'ecommerce': ecommerce}
    return render(request, "home.html", my_dict)



class EcommerceDetailView(DetailView):
    model = Ecommerce

@login_required(login_url='/register')
def confirm_view(request):
    form = ConfirmationForm()
    if request.method=='POST':
        form = ConfirmationForm(request.POST)
        if form.is_valid():
          form.save(commit=True)
        return redirect('/success')
    my_dict = {'form': form}
    return render(request, "order.html", my_dict)

@login_required(login_url='/register')
def end(request):
    return render(request, "success.html")








